//========HELO FRIEND========//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6289526842547"] 
global.namabot = 'DRAK EXECUTION'
//======================
module.exports = {
  openai_api_key: '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', // Ganti dengan API asli kamu
}
//======================
global.mess = { 
owner: '*WADUHH KHUSUS OWNER*',
premium: '*ANDA BUKAN USER PREMIUM KONTOL*',
succes: '*DONE YA KONTOL*'
}
//======================